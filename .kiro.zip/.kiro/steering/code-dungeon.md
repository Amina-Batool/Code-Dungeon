---
inclusion: always
---

# Code Dungeon — Development Guidelines

## Focus
RPG-style learning game development with gamification. Every change should make the game more engaging, rewarding, and fun to play.

## Preferences

### Gamification
- Use health bars, floating damage numbers, and level-up animations for all state changes
- Streak bonuses must be maintained for consecutive correct answers (🔥 combo multiplier)
- Show the correct answer whenever the player gets one wrong — never leave them confused
- Progressive difficulty: each dragon tier has more HP and higher attack power
- Keep losing recoverable — the player should always want to try again

### Visual Feedback
- Prefer animated visual feedback over text-heavy explanations
- Every player action should produce an immediate visual response (damage popup, bar update, animation)
- Use floating damage numbers for all HP/mana changes
- Screen shake on player hit, confetti on victory
- Milestone badges animate in with `badgePop` keyframe

### Code Constraints
- All code stays in `index.html` — do not split into separate files
- No external dependencies beyond Tailwind CSS CDN
- No build tools, bundlers, or package managers
- Mobile-first: test layout at 375px width before desktop

### Sound
- Sound effects use the Web Audio API only — no audio files or external URLs
- Sound is opt-in (default off); respect the `soundEnabled` flag
- Tones should reinforce feedback: high pitch for correct, low for wrong, ascending for level up

## Avoid
- External JS/CSS libraries beyond Tailwind CDN
- Complex build processes or module imports
- Punishing the player too harshly (losing should feel dramatic but not demoralizing)
- Text walls without accompanying visual feedback
- `display` inline styles for showing/hiding elements — use the `.hidden` class only

## Style Guide

### Theme
- Dark fantasy: deep purples, oranges, and reds
- Background: animated gradient (`#0f0c29 → #302b63 → #24243e`)
- Accent colors: yellow-300/orange-400 for player UI, red-400 for dragon UI, purple-300 for spells

### UI Layout
- Stats bar fixed at top, action buttons fixed at bottom
- Scrollable middle zone for problem text, answer options, and battle log
- Max width 600px centered — feels like a mobile app on desktop too

### Animations
- Transitions: 300–400ms, use `cubic-bezier(.4,0,.2,1)` for bar fills
- Button hover: `translateY(-2px)` with box-shadow glow
- Button active: `scale(0.97)`
- Keep animations snappy — nothing should feel sluggish

### Spacing & Shape
- Rounded corners: `rounded-xl` (12px) for cards, `rounded-2xl` for modals
- Consistent padding: `px-3 py-2` for compact elements, `p-6` for modals
- Borders: `border border-white/10` for subtle card edges

## Code Quality
- Use meaningful variable names that reflect game concepts (`dragonTier`, `questionsCorrect`, `streak`)
- Comment complex game logic with inline explanations
- Keep functions under 50 lines; extract helpers if a function grows beyond that
- Handle edge cases: empty input, API timeout, zero HP, max level
- Sanitize all user-provided content with `escapeHTML` before inserting into the DOM
- Use `const` for values that never change, `let` for mutable state

## Success Metrics
- Player understands the concept after seeing the correct answer explanation
- XP gain and level-up feel rewarding enough that the player wants to fight the next dragon
- Different problems produce meaningfully different question sets (replayability)
- The game is fully playable in Demo Mode without any API key
