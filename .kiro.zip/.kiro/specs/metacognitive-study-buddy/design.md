# Design Document: Code Dungeon ⚔️

## Overview

Code Dungeon is a single-file browser RPG (`index.html`) where players defeat dragons by answering AI-generated quiz questions about a coding or math problem they paste in. Everything — HTML structure, CSS animations, JavaScript game logic, and Groq API integration — lives in one self-contained file with no build step, no server, and no external dependencies beyond the Tailwind CSS CDN.

### Key Design Principles

- **Zero build toolchain**: A single `index.html` with inline `<style>` and `<script>` blocks. No bundler, no framework, no server.
- **Demo-first**: `DEMO_MODE = true` by default. The game is fully playable without an API key using pre-built, per-dragon question pools.
- **Immediate feedback**: Every player action produces a visual response within one animation frame — floating damage numbers, health bar transitions, emoji animations, and optional audio tones.
- **Progressive difficulty**: Four dragon tiers (Emberfang → Shadowbyte → NullReaper → StackBreakor) with escalating HP and attack power, each with a Phase 2 enrage state.
- **Mobile-first layout**: The battle screen is a fixed full-viewport column (max-width 600px) that works at 375px without horizontal scroll.

---

## Architecture

### High-Level Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                          index.html                              │
│  ┌──────────────┐   ┌─────────────────────────────────────────┐  │
│  │   <style>    │   │              <body>                     │  │
│  │  Tailwind    │   │  ┌───────────────────────────────────┐  │  │
│  │  (CDN)       │   │  │  #screen-quest  (Screen 1)        │  │  │
│  │  + custom    │   │  │  #screen-battle (Screen 2, fixed) │  │  │
│  │  keyframes   │   │  │  #hint-modal                      │  │  │
│  └──────────────┘   │  │  #victory-modal                   │  │  │
│                     │  │  #defeat-modal                    │  │  │
│  ┌──────────────┐   │  │  #confetti-canvas                 │  │  │
│  │  <script>    │   │  │  #milestone-banner                │  │  │
│  │  ─────────   │   │  └───────────────────────────────────┘  │  │
│  │  Config      │   └─────────────────────────────────────────┘  │
│  │  Game State  │                                                 │
│  │  Utilities   │                                                 │
│  │  Demo Data   │                                                 │
│  │  Audio       │                                                 │
│  │  Confetti    │                                                 │
│  │  Milestone   │                                                 │
│  │  Progress    │                                                 │
│  │  Battle Logic│                                                 │
│  │  UI Helpers  │                                                 │
│  │  Event Listnr│                                                 │
│  └──────────────┘                                                 │
└──────────────────────────────────────────────────────────────────┘
```

### Screen Navigation Model

Screens are toggled via the `.hidden` class. No routing, no SPA framework. Only one screen is visible at a time.

```
showScreen(id):
  1. ['screen-quest', 'screen-battle'].forEach(s => getElementById(s).classList.add('hidden'))
  2. getElementById(id).classList.remove('hidden')
```

Modals overlay on top of the active screen using `position: fixed` with a backdrop blur. They are shown/hidden independently of the screen.

### Deployment Target

Copy `index.html` to any static host (GitHub Pages, Netlify, Vercel). No build step. To enable live AI: create `config.js` from `config.example.js` and serve via a local HTTP server (see `INSTALL.md`).

---

## Components and Interfaces

### Component Map

```
index.html
├── #screen-quest
│   ├── #problem-input            textarea (max 10,000 chars)
│   ├── #subject-select           dropdown: Coding | Math
│   ├── #enter-dungeon-btn        starts a dungeon run
│   ├── #input-error              inline validation message
│   ├── #api-key-error            banner shown in Live Mode if key is invalid
│   ├── #demo-toggle-btn          toggles DEMO_MODE at runtime
│   ├── #sound-toggle             🔇/🔊 Web Audio toggle
│   └── #player-recap             dungeons cleared + hero level (hidden if 0)
│       ├── #dungeons-cleared
│       └── #recap-level
│
└── #screen-battle  (fixed full-viewport column, max-w 600px)
    ├── [Fixed] Stats bar
    │   ├── #player-hp-fill / #player-hp-text
    │   ├── #player-mana-fill / #player-mana-text
    │   ├── #player-level-display / #player-xp-fill
    │   ├── #dragon-hp-fill / #dragon-hp-text
    │   ├── #dragon-name-label / #dragon-phase-badge
    │   └── #questions-remaining-badge
    ├── [Fixed] Arena (#arena)
    │   ├── #mascot              hero emoji
    │   ├── #streak-badge        🔥 x<count>
    │   ├── #dragon-emoji
    │   └── #dragon-name-arena
    ├── [Fixed] #dragon-speech
    ├── [Scrollable] .battle-scroll-area
    │   ├── #problem-display
    │   ├── #battle-loading      spinner + #battle-loading-msg
    │   ├── #answer-options      dynamically rendered option buttons
    │   ├── #battle-error        error + retry button
    │   ├── #action-buttons      grid of 4 spell/action buttons
    │   │   ├── #hint-btn        📖 Hint Tome (-5 mana)
    │   │   ├── #fireball-btn    🔥 Fireball (-20 mana)
    │   │   ├── #heal-btn        💚 Heal (-15 mana)
    │   │   └── #potion-btn      🧪 Potion (-20 mana)
    │   └── #battle-log
    └── [Fixed] #retreat-btn

Modals (fixed, z-200, backdrop blur)
├── #hint-modal     → #hint-modal-body, #close-hint-modal
├── #victory-modal  → #victory-msg, #levelup-notice, #next-dragon-btn, #new-quest-btn
└── #defeat-modal   → #defeat-msg, #retry-battle-btn, #defeat-new-quest-btn

Overlays
├── #confetti-canvas   (fixed, z-9999, pointer-events: none)
└── #milestone-banner  (fixed bottom-6, z-50, pointer-events: none)
```

### JavaScript Module Overview

Each section in the `<script>` block is separated by a banner comment `// ════ Section ════`:

| Section | Contents |
|---|---|
| Configuration | `DEMO_MODE`, `API_KEY`, `API_URL`, `MODEL`, `TIMEOUT_MS`, `STORAGE_KEY` |
| Game State | `player`, `DRAGON_TEMPLATES`, `dragonTier`, `dragon`, `currentProblem`, `currentSubject`, `currentQuiz`, `questionIdx`, `questionsCorrect`, `battleLog`, `soundEnabled` |
| Utilities | `escapeHTML`, `fetchWithTimeout`, `validateApiKey`, `callLLMWithRetry` |
| Demo Data | `DEMO_QUIZ_DATA`, `generateFreshDemoQuestions` |
| Audio | `playTone`, named sound helpers (`playCorrectDing`, `playWrongSound`, etc.) |
| Confetti | `launchConfetti` (Canvas API particle system) |
| Milestone | `MILESTONES`, `maybeShowMilestone` |
| Progress | `getDungeonsCleared`, `incrementDungeons`, `refreshRecap` |
| Floating Numbers | `showDamagePopup` |
| Battle Log | `addToBattleLog` |
| UI Helpers | `updateBars`, `renderQuestion`, `showBattleError`, `clearBattleError`, `setActionButtonsEnabled` |
| Battle Logic | `startBattle`, `loadDragon`, `handleAnswer`, `handleCorrect`, `handleWrong`, `checkBattleEnd`, `advanceQuestion`, `checkLevelUp`, `regenerateMana`, `spendMana` |
| Event Listeners | Button click handlers, modal controls, retreat |

---

## Data Models

### Game State Variables

```js
// ── Player ──────────────────────────────────────────────────────────────────
let player = {
  hp:     100, maxHp:  100,    // Hit points
  mana:    50, maxMana: 50,    // Spell resource
  level:    1,                 // Hero level (1–n)
  xp:       0,                 // Accumulated experience points
  streak:   0                  // Consecutive correct answers (combo multiplier)
};

// ── Dragon Templates (immutable) ────────────────────────────────────────────
const DRAGON_TEMPLATES = [
  { name: 'Emberfang',    emoji: '🐉', hp: 120, maxHp: 120, attackPower: 15, speech: "..." },
  { name: 'Shadowbyte',   emoji: '🦎', hp: 150, maxHp: 150, attackPower: 20, speech: "..." },
  { name: 'NullReaper',   emoji: '🐲', hp: 180, maxHp: 180, attackPower: 25, speech: "..." },
  { name: 'StackBreakor', emoji: '🔥', hp: 220, maxHp: 220, attackPower: 30, speech: "..." },
];

// ── Active dragon (mutable copy of template + phase) ────────────────────────
let dragonTier = 0;
let dragon = { ...DRAGON_TEMPLATES[0], phase: 1 };

// ── Session ─────────────────────────────────────────────────────────────────
let currentProblem   = '';          // Raw problem text
let currentSubject   = 'Coding';    // Selected subject
let currentQuiz      = [];          // QuizQuestion[]
let questionIdx      = 0;           // Current question pointer
let questionsCorrect = 0;           // Running tally for the current dragon
let battleLog        = [];          // Entries for #battle-log
let soundEnabled     = false;       // Web Audio opt-in flag
```

### QuizQuestion Object

```js
/**
 * @typedef {Object} QuizQuestion
 * @property {string}          question  - Question text
 * @property {string[]}        options   - Exactly 4 options, e.g. ["A) ...", "B) ...", "C) ...", "D) ..."]
 * @property {"A"|"B"|"C"|"D"} correct   - Correct answer letter
 * @property {string}          concept   - Concept label shown on wrong answer
 * @property {boolean}         answered  - Mutated to true once the player selects an answer
 */
```

### XP Level Thresholds

```js
const XP_THRESHOLDS = [0, 50, 120, 220, 350, 520, 730, 990];
// player.level is the 1-based index; level N requires XP_THRESHOLDS[N-1] total XP
```

### Damage Formula

```
Correct answer damage to dragon:  20 + (player.streak × 5)
Wrong answer damage to player:    dragon.attackPower
Fireball spell damage to dragon:  50  (costs 20 mana)
```

### Mana Costs and Heal Amounts

| Action | Mana Cost | Effect |
|---|---|---|
| Hint Tome | 5 | Opens hint modal |
| Fireball | 20 | Deals 50 damage to dragon |
| Heal | 15 | Restores 30 HP to player |
| Potion | 20 | Restores 60 HP to player |
| Answer (any) | −10 (regenerated) | Mana restored after each answered question |

### localStorage Schema

| Key | Type | Default | Description |
|---|---|---|---|
| `cd_dungeons_cleared` | string (integer ≥ 0) | `"0"` | Count of completed full dungeon runs (all 4 dragons defeated) |

On read: `parseInt(localStorage.getItem('cd_dungeons_cleared'), 10)`. If `NaN` or `< 0`, return 0.

### Milestone Definitions

```js
const MILESTONES = {
  3:  { emoji: '⭐', text: '3 Dungeons Cleared!' },
  5:  { emoji: '🌟', text: '5 Dungeons — Hero Rising!' },
  10: { emoji: '🔥', text: '10 Dungeons — Legendary!' },
  25: { emoji: '🏆', text: '25 Dungeons — Grand Master!' }
};
```

---

## Battle Flow

### Full Battle Sequence

```
Player submits problem → startBattle()
  │
  ├── loadDragon(dragonTier)     — reset dragon to template values, update UI
  ├── resetPlayerForBattle()     — hp/mana to max (preserve level/xp), streak = 0
  ├── clearBattleLog()
  ├── generateQuestions()        — Demo Mode or Groq API call
  │     ├── show #battle-loading spinner
  │     ├── [Demo] generateFreshDemoQuestions(problem, subject, dragonName)
  │     └── [Live] callLLMWithRetry → parseQuizResponse
  ├── hide #battle-loading
  └── renderQuestion(0)          — show first question + action buttons
         │
         └── Player selects answer
               │
               ├── handleCorrect() or handleWrong()
               │     ├── Update HP/mana bars
               │     ├── Show floating damage popup
               │     ├── Animate mascot + dragon
               │     ├── Update battle log
               │     ├── Update streak badge
               │     ├── checkBattleEnd()
               │     │     ├── Dragon HP ≤ 0 → showVictory()
               │     │     └── Player HP ≤ 0 → showDefeat()
               │     └── regenerateMana(+10)
               │
               └── setTimeout(1200ms) → advanceQuestion()
                     ├── questionIdx++
                     ├── If questionIdx < currentQuiz.length → renderQuestion(questionIdx)
                     └── If questionIdx === currentQuiz.length → generateQuestions() (loop)
```

### Phase 2 Trigger

```js
if (dragon.hp <= dragon.maxHp * 0.5 && dragon.phase === 1) {
  dragon.phase = 2;
  document.getElementById('dragon-emoji').classList.add('dragon-enraged');
  // Update dragon name label to include " 💀 ENRAGED"
  addToBattleLog(`${dragon.name} enters PHASE 2! 💀`, 'system');
}
```

---

## LLM Integration

### Configuration Loading

API credentials are never hardcoded. On startup the script attempts:

```js
if (typeof LIVE_CONFIG !== 'undefined' && LIVE_CONFIG.API_KEY &&
    LIVE_CONFIG.API_KEY !== 'your_groq_api_key_here') {
  DEMO_MODE = LIVE_CONFIG.DEMO_MODE ?? false;
  API_KEY   = LIVE_CONFIG.API_KEY;
  MODEL     = LIVE_CONFIG.MODEL ?? MODEL;
}
```

`config.js` is gitignored and loaded via `<script src="config.js" onerror="...">`. If absent, `DEMO_MODE` stays `true` and no API calls are made.

### Quiz Generation Request (Live Mode)

```
POST https://api.groq.com/openai/v1/chat/completions
Authorization: Bearer {API_KEY}
Content-Type: application/json

{
  "model": "llama-3.3-70b-versatile",
  "messages": [{
    "role": "user",
    "content": "You are a quiz generator for a coding/math RPG game. Based on the following {subject} problem, generate EXACTLY 5 multiple-choice questions that test conceptual understanding.\n\nPROBLEM:\n{problem}\n\nReturn ONLY a valid JSON array with this exact schema:\n[{\"question\":\"...\",\"options\":[\"A) ...\",\"B) ...\",\"C) ...\",\"D) ...\"],\"correct\":\"A\",\"concept\":\"...\"}]\n\nRules:\n- 4 answer options per question (A-D), exactly one correct\n- Test concepts, not memorisation of the exact problem text\n- 'concept' is a short label for what to review if wrong\n- No direct answers or complete solutions"
  }],
  "temperature": 0.7,
  "max_tokens": 1200
}
```

### Quiz Response Parser

```js
function parseQuizResponse(rawText) {
  const match = rawText.match(/\[[\s\S]*\]/);
  if (!match) throw new Error('No JSON array found in response');
  const arr = JSON.parse(match[0]);
  if (!Array.isArray(arr) || arr.length < 3) throw new Error('Expected at least 3 questions');
  return arr.slice(0, 5).map(q => ({ ...q, answered: false }));
}
```

### Hint Generation Request (Live Mode)

```
POST https://api.groq.com/openai/v1/chat/completions
{
  "model": "llama-3.3-70b-versatile",
  "messages": [{
    "role": "user",
    "content": "You are a patient tutor in a coding RPG. The student is working on this {subject} problem:\n\nPROBLEM: {problem}\n\nDo NOT give the answer. Respond with EXACTLY THREE bullet points:\nThink about: [one concept to review]\nTry breaking it down: [one smaller sub-problem]\nCommon mistake to avoid: [one relevant trap]\n\nNo other text."
  }],
  "temperature": 0.7,
  "max_tokens": 400
}
```

### Hint Response Parser

```js
function parseHints(rawText) {
  const lines    = rawText.split('\n').map(l => l.trim()).filter(Boolean);
  const prefixes = ['Think about:', 'Try breaking it down:', 'Common mistake to avoid:'];
  return prefixes.map(p => {
    const line = lines.find(l => l.startsWith(p));
    if (!line) throw new Error(`Missing hint: ${p}`);
    return line;
  });
}
```

### Retry Wrapper

```js
async function callLLMWithRetry(bodyObj, onRetryMsg, maxRetries = 3) {
  // exponential backoff: 2s, 4s, 8s on HTTP 429
  // fetchWithTimeout rejects after TIMEOUT_MS (30,000ms) via AbortController
  // throws typed errors: TimeoutError, RateLimitError, or generic Error with status code
}
```

---

## Demo Mode Data Architecture

`generateFreshDemoQuestions(problem, subject, dragonName)` selects 5 shuffled questions from a per-dragon pool (`DRAGON_POOLS`). Each dragon has 5 questions themed to its conceptual tier:

| Dragon | Conceptual Focus |
|---|---|
| Emberfang (Tier 0) | Problem analysis, decomposition, planning, iteration basics, testing |
| Shadowbyte (Tier 1) | Edge cases, time complexity, loop safety, linear search, bounds checking |
| NullReaper (Tier 2) | Data structures, complexity classes, null safety, recursion, call stack |
| StackBreakor (Tier 3) | Recursion base cases, stack overflow, design patterns, Big-O, dynamic programming |

The pool questions also inspect the problem text for keywords (`for`, `array`, `Math`, etc.) and swap in context-appropriate variants where applicable. The pool is shuffled per battle so repeated runs vary the question order.

---

## Error Handling

### Error Categories

| Category | Trigger | Display Location | Recovery |
|---|---|---|---|
| Validation error | Empty/whitespace problem on quest screen | `#input-error` (inline) | Player edits input |
| Demo mode | No valid config.js or API key | `#api-key-error` banner | Automatically falls back to Demo Mode |
| Network error | `fetch` rejects (offline, DNS) | `#battle-error` | "Try Again" button |
| Timeout error | No response within 30s | `#battle-error` | "Try Again" button |
| Rate limit | HTTP 429 after 3 retries | `#battle-error` | "Try Again" button or switch to Demo Mode |
| HTTP error | Non-2xx response | `#battle-error` with status code | "Try Again" button |
| Parse error | JSON array not found / invalid shape | `#battle-error` | "Try Again" button |
| Insufficient mana | Spell click with mana below cost | Battle log entry | No retry needed |

### Retry Semantics

The "Try Again" callback always captures the original parameters (`problem`, `subject`, `dragonName`) at call time and retries the identical API request — not a new one re-read from the DOM.

### Loading State Protocol

```
1. Show #battle-loading (spinner + message)
2. Hide #answer-options, #action-buttons
3. Disable #retreat-btn
4. [API call]
5. Hide #battle-loading
6. Show #answer-options, #action-buttons
7. Re-enable #retreat-btn
8. On failure: show #battle-error with message + retry button
```

---

## UI Layout and Styling

### Theme Palette

| Token | Value | Use |
|---|---|---|
| Background | `#0f0c29 → #302b63 → #24243e` (animated gradient) | Page background |
| Surface | `rgba(255,255,255,0.05)` | Card backgrounds |
| Border | `rgba(255,255,255,0.10)` | Card borders |
| Player accent | `yellow-300 / orange-400` | Player HP, level, XP |
| Dragon accent | `red-400` | Dragon HP, dragon name |
| Spell accent | `purple-300 / purple-400` | Hint Tome, mana |
| Correct feedback | `#22c55e` (green-500) | Correct option highlight, damage popup |
| Wrong feedback | `#ef4444` (red-500) | Wrong option highlight, player damage popup |
| Heal feedback | `#a78bfa` (violet-400) | Heal popup |
| System log | `#fbbf24` (yellow-400) | Battle log system messages |

### Battle Screen Layout

```
┌──────────────────────────────────┐  ← fixed top
│  Stats bar (HP, mana, XP, level) │
│  Arena (hero VS dragon)          │
│  Dragon speech bubble            │
├──────────────────────────────────┤
│                                  │  ← flex-1, overflow-y: auto
│  Problem display                 │
│  Answer options OR loading       │
│  Action buttons (2×2 grid)       │
│  Battle log                      │
│                                  │
├──────────────────────────────────┤  ← fixed bottom
│  Retreat button                  │
└──────────────────────────────────┘
```

### CSS Animation Summary

| Animation | Class | Duration | Trigger |
|---|---|---|---|
| Background gradient shift | `body` | 20s infinite | Always |
| Dragon enrage glow | `dragon-enraged` | 1s alternate infinite | Phase 2 |
| Screen shake | `screen-shake` | 0.35s | Player takes damage |
| Critical flash | `crit-flash` | 0.4s | Critical hit |
| Floating number | `dmg-popup` + `floatUp` | 1s | Any HP/mana change |
| Hero attack | `avatar-attack` | 0.4s | Correct answer |
| Hero hit | `avatar-hit` | 0.3s | Wrong answer |
| Hero celebrate | `avatar-celebrate` | 0.5s × 3 | Level-up |
| Hero think | `avatar-think` | 1.2s infinite | Loading |
| Dragon attack | `dragon-attack` | 0.45s | Wrong answer |
| Dragon hit | `dragon-hit` | 0.35s | Correct answer |
| Milestone badge pop | `milestone-badge` | 0.45s | Milestone reached |
| Badge counter pulse | `badge-pulse` | 0.35s | Questions remaining updates |
| Health bar fill | CSS `transition` | 0.4s cubic-bezier(.4,0,.2,1) | Any HP/mana change |
| Confetti particles | Canvas RAF | 2.8s | Full dungeon cleared |

### Button Styles

| Type | Hover | Active |
|---|---|---|
| Option button (`.option-btn`) | `translateY(-2px)` + blue shadow | `scale(0.97)` |
| Action button (`.action-btn`) | `scale(1.06)` + dark shadow | `scale(0.97)` |

### Tailwind CDN Configuration

```html
<script src="https://cdn.tailwindcss.com"></script>
<script>
  tailwind.config = {
    theme: { extend: { fontFamily: { sans: ['Inter', 'system-ui', 'sans-serif'] } } }
  }
</script>
```

---

## File Structure

```
index.html
├── <head>
│   ├── <meta charset="UTF-8">
│   ├── <meta name="viewport" content="width=device-width, initial-scale=1.0">
│   ├── <title>Code Dungeon ⚔️</title>
│   ├── <script src="https://cdn.tailwindcss.com">
│   ├── <script src="config.js" onerror="...">     ← gitignored, optional live config
│   ├── <script> tailwind.config = {...} </script>
│   └── <style> ... </style>                       ← all custom CSS (keyframes, bars, layout)
│
└── <body class="font-sans text-white select-none">
    ├── <canvas id="confetti-canvas">
    ├── <div id="milestone-banner">
    ├── <div id="screen-quest">                    ← Screen 1: problem input
    ├── <div id="screen-battle" class="hidden">    ← Screen 2: battle arena
    ├── <div id="hint-modal" class="hidden">       ← Modal: Ancient Tome
    ├── <div id="victory-modal" class="hidden">    ← Modal: Victory
    ├── <div id="defeat-modal" class="hidden">     ← Modal: Defeat
    └── <script> ... </script>                     ← all JS (sections separated by banner comments)
```

---

## Correctness Properties

### Property 1: Empty problem is rejected

For any string composed entirely of whitespace, clicking "Enter the Dungeon" SHALL keep the Player on `#screen-quest` and display a validation message in `#input-error`.

**Validates: Requirement 1.4**

---

### Property 2: Valid problem starts a battle

For any string with at least one non-whitespace character and a selected Subject, clicking "Enter the Dungeon" SHALL hide `#screen-quest`, show `#screen-battle`, and begin quiz generation.

**Validates: Requirement 1.5**

---

### Property 3: Correct answer damage formula

For any `player.streak` value k ≥ 0, a correct answer SHALL deal exactly `20 + (k × 5)` damage to the dragon.

**Validates: Requirement 4.2**

---

### Property 4: Wrong answer damage equals dragon attack power

For any dragon with `attackPower` p, a wrong answer SHALL reduce `player.hp` by exactly p (clamped at 0).

**Validates: Requirement 5.2**

---

### Property 5: Streak resets on wrong answer

After any wrong answer, `player.streak` SHALL equal 0 regardless of its previous value.

**Validates: Requirement 5.4**

---

### Property 6: Mana cost gates spells

For any spell action with cost c, if `player.mana < c` the spell effect SHALL NOT be applied and mana SHALL NOT be reduced.

**Validates: Requirement 9.2–9.5**

---

### Property 7: Dragon Phase 2 triggers at ≤ 50% HP

For any dragon with `maxHp` M, Phase 2 SHALL be triggered exactly once when `dragon.hp ≤ M * 0.5` and `dragon.phase === 1`.

**Validates: Requirement 7.4**

---

### Property 8: HP values are always clamped to [0, max]

For any damage or heal amount, `player.hp` SHALL remain in `[0, player.maxHp]` and `dragon.hp` SHALL remain in `[0, dragon.maxHp]`.

**Validates: Requirements 4.3, 5.3**

---

### Property 9: escapeHTML neutralises all HTML special characters

For any string containing `<`, `>`, `&`, `"`, or `'`, `escapeHTML` SHALL replace every such character with its HTML entity (`&lt;`, `&gt;`, `&amp;`, `&quot;`, `&#39;`). The transformation SHALL be reversible.

**Validates: Requirement 14.5**

---

### Property 10: fetchWithTimeout rejects after 30 seconds

For any fetch call that does not resolve within 30,000ms, `fetchWithTimeout` SHALL abort via `AbortController` and throw a `TimeoutError`.

**Validates: Requirement 14.6**

---

### Property 11: Dungeon counter increments exactly once per full clear

For any integer n ≥ 0 stored under `cd_dungeons_cleared`, defeating DragonTier 3 SHALL result in `localStorage` storing `n + 1` and `#dungeons-cleared` displaying `n + 1`.

**Validates: Requirement 12.4**

---

### Property 12: localStorage initialises to 0 for any invalid stored value

For any value stored under `cd_dungeons_cleared` that is absent, non-numeric, or negative, `getDungeonsCleared()` SHALL return 0.

**Validates: Requirement 12.3**

---

### Property 13: Demo mode generates 5 questions without an API call

In Demo Mode, `generateFreshDemoQuestions` SHALL return exactly 5 `QuizQuestion` objects with `answered: false` without making any network request.

**Validates: Requirement 3.2**

---

### Property 14: Answer buttons lock after selection

For any `QuizQuestion`, after the player selects any option, all option buttons for that question SHALL be disabled so no further selection is possible.

**Validates: Requirements 4.1, 5.1**

---

### Property 15: Sound is silent when soundEnabled is false

For any `playTone` call when `soundEnabled === false`, no `AudioContext` SHALL be created and no audio SHALL be produced.

**Validates: Requirement 15.4**
