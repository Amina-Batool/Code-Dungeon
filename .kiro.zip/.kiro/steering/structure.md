# Project Structure

## File Layout
```
code-dungeon/
├── index.html        # Entire game — single self-contained file
└── README.md         # Setup instructions and feature reference
```

## index.html Internal Organization
The file is divided into three main sections in order:

### 1. `<head>` — Styles & Config
- Tailwind CDN script + config block
- All custom CSS in a single `<style>` block
- Sections within CSS are marked with `/* ── Section Name ── */` comments

### 2. `<body>` — Markup
Screens are toggled via `.hidden` class (never `display` inline styles):
| Element ID | Purpose |
|---|---|
| `#screen-quest` | Quest entry / problem input (Screen 1) |
| `#screen-battle` | Battle arena (Screen 2) |
| `#hint-modal` | Hint Tome modal |
| `#victory-modal` | Victory modal |
| `#defeat-modal` | Defeat modal |
| `#confetti-canvas` | Full-viewport confetti overlay |
| `#milestone-banner` | Fixed milestone badge container |

### 3. `<script>` — JavaScript
Sections are separated by banner comments (`// ═══ Section ═══`):

| Section | Contents |
|---|---|
| Configuration | `DEMO_MODE`, `API_KEY`, `MODEL`, timeouts |
| Game State | `player`, `dragon`, `currentQuiz`, counters |
| Utilities | `escapeHTML`, `fetchWithTimeout`, `callLLMWithRetry` |
| Demo Data | `DEMO_QUIZ_DATA`, `generateFreshDemoQuestions` |
| Game Logic | Battle flow, damage, healing, leveling, streaks |
| UI Helpers | DOM updates, animations, battle log, floating numbers |
| Event Listeners | Button handlers, modal controls, screen transitions |
| Audio | Web Audio API tone generators |

## Conventions
- All DOM queries use `document.getElementById` — IDs are the source of truth for element references
- Screen visibility is controlled exclusively by toggling the `hidden` class
- Game state lives in module-level `let` variables (`player`, `dragon`, `currentQuiz`, etc.)
- CSS animation classes are added/removed programmatically and cleaned up after the animation ends
- `localStorage` key: `cd_dungeons_cleared`
