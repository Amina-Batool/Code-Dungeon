# Tech Stack

## Overview
Single-file vanilla web app — everything lives in `index.html`. No build tools, bundlers, or package managers.

## Stack
| Layer | Technology |
|---|---|
| Structure | HTML5 |
| Styling | Tailwind CSS (CDN: `cdn.tailwindcss.com`) |
| Logic | Vanilla JavaScript (ES2020+) |
| AI | Groq API — LLaMA 3.3 70B (`llama-3.3-70b-versatile`) |
| Audio | Web Audio API (no external audio files) |
| Animation | CSS keyframes + Canvas API (confetti) |
| Persistence | `localStorage` |

## External Dependencies
- **Tailwind CSS CDN only** — no other external libraries, frameworks, or scripts
- Groq REST API (`https://api.groq.com/openai/v1/chat/completions`) for quiz generation and hints

## AI Integration
- API calls use a `fetchWithTimeout` wrapper (30 s timeout)
- Retry logic with exponential backoff handles HTTP 429 rate-limit responses (up to 3 attempts)
- `DEMO_MODE = true` bypasses all API calls and serves pre-built question pools — leave enabled for offline/judge use

## Configuration (top of `<script>` block in index.html)
```js
let DEMO_MODE = true;          // true = no API key needed
const API_KEY = "...";         // Groq key — get free at console.groq.com/keys
const MODEL   = "llama-3.3-70b-versatile";
const TIMEOUT_MS = 30000;
```

## Common Commands
There is no build or compile step.

| Task | Command |
|---|---|
| Run the game | Open `index.html` in any modern browser |
| Enable live AI | Set `DEMO_MODE = false` and add a valid `API_KEY` in `index.html` |
| Deploy | Copy `index.html` to any static host (GitHub Pages, Netlify, etc.) |

## Browser Requirements
Modern evergreen browser with support for: ES2020, CSS custom properties, Web Audio API, Canvas API, `localStorage`, `fetch`.
