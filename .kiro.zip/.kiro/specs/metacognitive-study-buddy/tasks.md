# Implementation Plan: Metacognitive Study Buddy

## Overview

Implement a single `index.html` file (vanilla JS + Tailwind CDN, no build tools) that guides students through a four-step metacognitive workflow: Input → Explain → Hints → Quiz. The implementation follows the internal script layout defined in the design document, building each layer incrementally before wiring everything together.

All property-based tests use **fast-check** (loaded via CDN or a separate test file) with a minimum of 100 iterations per property.

---

## Tasks

- [x] 1. Project scaffold — HTML shell and Tailwind setup
  - Create `index.html` with valid HTML5 doctype, `<head>`, `<body>`, and `<footer>` skeleton
  - Add `<meta charset="UTF-8">` and `<meta name="viewport" content="width=device-width, initial-scale=1.0">`
  - Add `<title>Metacognitive Study Buddy</title>`
  - Load Tailwind CDN: `<script src="https://cdn.tailwindcss.com"></script>`
  - Add inline `tailwind.config` script extending `fontFamily.sans` with Inter
  - Add `<style>` block with `.step-panel` transition rules and spinner keyframe animation
  - Set `<body class="bg-[#FAFAFA] min-h-screen font-sans">`
  - Add placeholder `<div>` regions for: `#progress-tracker`, `#step-indicator`, `#step-input`, `#step-explain`, `#step-hints`, `#step-quiz`, `#footer`
  - _Requirements: 6.1, 6.2, 6.3_

- [x] 2. Utility functions
  - [x] 2.1 Implement `escapeHTML(str)`
    - Replace `<`, `>`, `&`, `"`, `'` with HTML entities using a single-pass replace map
    - Add inline JSDoc comment
    - _Requirements: 7.5_

  - [ ]* 2.2 Write property test for `escapeHTML` — Property 19
    - **Property 19: escapeHTML converts all HTML special characters to entities**
    - **Validates: Requirements 7.5**
    - Generator: `fc.string()` with injected `<>'"&` characters
    - Assert: no raw special characters remain; `unescape(output) === input` (round-trip)
    - Tag: `// Feature: metacognitive-study-buddy, Property 19`

  - [x] 2.3 Implement `fetchWithTimeout(url, options, ms)`
    - Use `AbortController`; reject with a `TimeoutError` instance after `ms` milliseconds
    - Clear the timeout on successful response
    - _Requirements: 7.4_

  - [ ]* 2.4 Write property test for `fetchWithTimeout` — Property 18
    - **Property 18: fetchWithTimeout rejects after 30 seconds without a response**
    - **Validates: Requirements 7.4**
    - Mock a fetch that never resolves; assert rejection with `TimeoutError` after 30 000 ms
    - Tag: `// Feature: metacognitive-study-buddy, Property 18`

  - [x] 2.5 Implement `nonWhitespaceCount(str)` and `validateProblem(str)`
    - `nonWhitespaceCount`: count characters where `char.trim() !== ''`
    - `validateProblem`: return `true` iff `nonWhitespaceCount(str) > 0`
    - _Requirements: 1.4, 1.5, 2.3, 2.4_

  - [x] 2.6 Implement `validateApiKey(key)`
    - Return `false` for `''`, `undefined`, `null`, `"YOUR_API_KEY_HERE"`; `true` otherwise
    - _Requirements: 7.1_

  - [ ]* 2.7 Write property test for `validateApiKey` — Property 16
    - **Property 16: API key validation rejects any placeholder or empty value**
    - **Validates: Requirements 7.1**
    - Generator: `fc.constantFrom('', undefined, null, 'YOUR_API_KEY_HERE')`
    - Assert: `validateApiKey(value) === false`
    - Tag: `// Feature: metacognitive-study-buddy, Property 16`

  - [ ]* 2.8 Write property tests for `validateProblem` and `nonWhitespaceCount` — Properties 1 & 2
    - **Property 1: Whitespace-only problems are rejected**
    - **Property 2: Valid problem input advances to the Explain step**
    - **Validates: Requirements 1.4, 1.5**
    - P1 generator: `fc.stringOf(fc.constantFrom(' ', '\t', '\n'))`; assert `validateProblem` returns `false`
    - P2 generator: `fc.string().filter(s => s.trim().length > 0)`; assert `validateProblem` returns `true`
    - Tag: `// Feature: metacognitive-study-buddy, Property 1` and `Property 2`

- [x] 3. Checkpoint — Verify utility functions
  - Ensure all tests pass, ask the user if questions arise.

- [x] 4. ProgressTracker module
  - [x] 4.1 Implement `getCount()`, `incrementCount()`, `renderCount()`
    - `STORAGE_KEY = 'msb_session_count'`
    - `getCount`: parse `localStorage.getItem(STORAGE_KEY)` with `parseInt`; return `0` for `NaN`, negative, or non-safe-integer values
    - `incrementCount`: call `getCount()`, add 1, write back to `localStorage`, call `renderCount()`
    - `renderCount`: set `#progress-display` inner text to the current count
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

  - [ ]* 4.2 Write property test for `getCount` with invalid storage values — Property 15
    - **Property 15: ProgressTracker initialises to 0 for any invalid stored value**
    - **Validates: Requirements 5.3**
    - Generator: `fc.constantFrom(undefined, null, '', 'abc', '-1', '1.5')`
    - Seed `localStorage` with each value before calling `getCount()`; assert return value is `0`
    - Tag: `// Feature: metacognitive-study-buddy, Property 15`

  - [ ]* 4.3 Write property test for `incrementCount` — Property 14
    - **Property 14: Quiz completion increments and displays the session count**
    - **Validates: Requirements 4.6, 5.2, 5.4, 5.5**
    - Generator: `fc.integer({ min: 0, max: 9999 })`
    - Seed `localStorage` with `n`, call `incrementCount()`, assert `localStorage` holds `n + 1` and `#progress-display` shows `n + 1`
    - Tag: `// Feature: metacognitive-study-buddy, Property 14`

- [x] 5. StepController module
  - [x] 5.1 Implement `showStep(stepId)` and `updateStepIndicator(stepId)`
    - `showStep`: hide all `.step-panel` elements, reveal the target panel, apply fade-in via `requestAnimationFrame`, call `updateStepIndicator`
    - `updateStepIndicator`: remove active classes from all `.step-dot` elements; add `text-blue-500 font-semibold border-b-2 border-blue-500` to the dot whose `data-step` matches `stepId`
    - Transition must complete within 400ms (use 300ms CSS transition)
    - _Requirements: 1.6, 6.5, 6.6_

  - [ ]* 5.2 Write property test for `updateStepIndicator` — Property 3
    - **Property 3: StepIndicator reflects the active step**
    - **Validates: Requirements 1.6, 6.6**
    - Generator: `fc.constantFrom('step-input', 'step-explain', 'step-hints', 'step-quiz')`
    - After calling `showStep(stepId)`, assert exactly one `.step-dot` carries the active class and its `data-step` matches `stepId`
    - Tag: `// Feature: metacognitive-study-buddy, Property 3`

- [x] 6. Step 1 — Input step UI and validation
  - [x] 6.1 Build `#step-input` markup
    - `<textarea id="problem-input">` (max 10 000 chars), `<select id="subject-select">` with "Coding" (default) and "Math" options, `<button id="start-btn">Start Studying</button>`, `<div id="input-error">`
    - Apply Tailwind utility classes; ensure responsive layout (`mx-auto max-w-2xl w-full px-4`)
    - _Requirements: 1.1, 1.2, 1.3_

  - [x] 6.2 Implement `initInputStep()` event listeners
    - On `start-btn` click: call `validateProblem`; if false, show inline error in `#input-error`; if true, store `currentProblem` and `currentSubject`, call `showStep('step-explain')` and `initExplainStep()`
    - Clear `#input-error` on successful validation
    - _Requirements: 1.4, 1.5_

- [x] 7. Step 2 — Explain step UI, counter, I'm Stuck, and Get Hints gate
  - [x] 7.1 Build `#step-explain` markup
    - Display heading: "Before we help, explain your approach step-by-step:"
    - `<textarea id="reasoning-input">`, `<div id="char-counter">`, `<button id="get-hints-btn" disabled>Get Hints</button>`, `<button id="stuck-btn">I'm Stuck</button>`, `<div id="stuck-question">`
    - _Requirements: 2.1, 2.2, 2.3, 2.6_

  - [x] 7.2 Implement `initExplainStep()` — counter and button gate logic
    - On `reasoning-input` input: compute `nonWhitespaceCount`; update `#char-counter` ("X more characters needed" when < 50; hide when ≥ 50); toggle `get-hints-btn` disabled state
    - On `get-hints-btn` click: store `currentReasoning`, call `showStep('step-hints')`, call `initHintsStep()`
    - _Requirements: 2.3, 2.4, 2.5, 2.8_

  - [x] 7.3 Implement I'm Stuck cycling logic
    - Define `STUCK_QUESTIONS` array (5 strings) and `stuckIndex = 0`
    - On `stuck-btn` click: display `STUCK_QUESTIONS[stuckIndex % 5]` in `#stuck-question`; increment `stuckIndex`
    - _Requirements: 2.6, 2.7_

  - [ ]* 7.4 Write property test for Get Hints button state — Property 4
    - **Property 4: Get Hints button state matches the 50-character threshold**
    - **Validates: Requirements 2.3, 2.5**
    - Generator: `fc.string()`; derive `k = nonWhitespaceCount(s)`
    - Simulate `reasoning-input` event; assert button disabled when `k < 50`, enabled when `k >= 50`
    - Tag: `// Feature: metacognitive-study-buddy, Property 4`

  - [ ]* 7.5 Write property test for the character counter display — Property 5
    - **Property 5: Character counter shows the correct remaining count**
    - **Validates: Requirements 2.4**
    - Generator: `fc.string().map(s => ({ s, k: nonWhitespaceCount(s) })).filter(({ k }) => k < 50)`
    - Assert `#char-counter` text contains `(50 - k)` and the string "more characters needed"
    - Tag: `// Feature: metacognitive-study-buddy, Property 5`

  - [ ]* 7.6 Write property test for I'm Stuck cycling — Property 6
    - **Property 6: I'm Stuck cycles through all questions in order**
    - **Validates: Requirements 2.7**
    - Generator: `fc.integer({ min: 1, max: 100 })`
    - Simulate `n` clicks; assert displayed question equals `STUCK_QUESTIONS[(n - 1) % 5]`
    - Tag: `// Feature: metacognitive-study-buddy, Property 6`

- [x] 8. Checkpoint — Verify input and explain steps
  - Ensure all tests pass, ask the user if questions arise.

- [x] 9. HintEngine module
  - [x] 9.1 Implement `buildHintPrompt(problem, subject, reasoning)`
    - Interpolate problem, subject, and reasoning into the exact prompt template from the design document
    - Return the complete prompt string; do not call the API here
    - _Requirements: 3.1, 7.2_

  - [ ]* 9.2 Write property test for `buildHintPrompt` — Property 7
    - **Property 7: Hint prompt contains all three interpolated values**
    - **Validates: Requirements 3.1, 7.2**
    - Generator: `fc.tuple(fc.string(), fc.string(), fc.string()).filter(([p,s,r]) => p.length > 0 && s.length > 0 && r.length > 0)`
    - Assert the returned string contains each of the three inputs as a distinct substring
    - Tag: `// Feature: metacognitive-study-buddy, Property 7`

  - [x] 9.3 Implement `parseHints(rawText)`
    - Split on `\n`, trim, filter blanks
    - Find lines starting with each of the three prefixes; throw `HintParseError` if any prefix is missing
    - Return `string[3]` in prefix order
    - _Requirements: 3.2_

  - [ ]* 9.4 Write property test for `parseHints` — Property 8
    - **Property 8: Hint parser extracts exactly three correctly prefixed hints**
    - **Validates: Requirements 3.2**
    - Generator for valid input: `fc.record({ think: fc.string(), breakdown: fc.string(), mistake: fc.string() })`; assemble well-formed response text; assert array of length 3 with correct prefixes
    - Generator for invalid input: text missing one or more prefixes; assert `HintParseError` is thrown
    - Tag: `// Feature: metacognitive-study-buddy, Property 8`

  - [x] 9.5 Implement `generateHints(problem, subject, reasoning)`
    - Call `fetchWithTimeout(API_URL, requestBody, TIMEOUT_MS)` with the hint prompt
    - On success: extract `choices[0].message.content`, call `parseHints`, return result
    - On network error, timeout, non-2xx response, or `HintParseError`: throw a typed error with a descriptive message
    - _Requirements: 3.1, 3.7, 7.4_

- [x] 10. Step 3 — Hints step UI
  - [x] 10.1 Build `#step-hints` markup
    - `<div id="loading-indicator">` (spinner; hidden by default), `<div id="hints-container">`, `<button id="test-btn" class="hidden">Test My Understanding</button>`, `<div id="hints-error">`
    - _Requirements: 3.3, 3.4, 3.6_

  - [x] 10.2 Implement `renderHints(hints)` and `initHintsStep()`
    - `renderHints`: for each hint string, create a card `<div>` with `escapeHTML`-escaped text; append to `#hints-container`; show `#test-btn`
    - `initHintsStep`: show `#loading-indicator`, call `generateHints`, on success call `renderHints` and hide loader; on error call `showError('#hints-error', message, retryFn)`
    - On `test-btn` click: call `showStep('step-quiz')`, call `initQuizStep()`
    - _Requirements: 3.3, 3.4, 3.6, 3.7_

  - [ ]* 10.3 Write property test for `renderHints` — Property 9
    - **Property 9: All rendered hints appear in the DOM**
    - **Validates: Requirements 3.4**
    - Generator: `fc.tuple(fc.string(), fc.string(), fc.string())`
    - After calling `renderHints([h1, h2, h3])`, assert all three strings are present in `#hints-container` text content
    - Tag: `// Feature: metacognitive-study-buddy, Property 9`

  - [ ]* 10.4 Write property test for error handling — Property 10
    - **Property 10: LLM error handling shows message and retry for any failure type**
    - **Validates: Requirements 3.7, 4.7**
    - Generator: `fc.constantFrom('NetworkError', 'TimeoutError', 'HintParseError', 'QuizParseError', 'HTTPError')`
    - For each error type, call `showError` with that error; assert descriptive message is in DOM and "Try Again" button is rendered
    - Tag: `// Feature: metacognitive-study-buddy, Property 10`

- [x] 11. Checkpoint — Verify HintEngine and hints step
  - Ensure all tests pass, ask the user if questions arise.

- [x] 12. QuizEngine module
  - [x] 12.1 Implement `buildQuizPrompt(problem, subject, hints)`
    - Interpolate problem, subject, and all three hint strings (joined with `\n`) into the quiz prompt template from the design document
    - Return the complete prompt string
    - _Requirements: 4.1, 7.3_

  - [ ]* 12.2 Write property test for `buildQuizPrompt` — Property 17
    - **Property 17: Quiz prompt contains problem, subject, and all three hints**
    - **Validates: Requirements 7.3**
    - Generator: `fc.tuple(fc.string(), fc.string(), fc.tuple(fc.string(), fc.string(), fc.string()))` (all non-empty)
    - Assert the returned string contains problem, subject, and each of the three hint strings as distinct substrings
    - Tag: `// Feature: metacognitive-study-buddy, Property 17`

  - [x] 12.3 Implement `parseQuiz(rawText)`
    - Extract first `[...]` block with regex `\[[\s\S]*\]`; throw `QuizParseError` if no match
    - `JSON.parse` the match; throw `QuizParseError` if not an array or length < 2
    - Map each element to `{ ...q, answered: false, correct_: false }`
    - _Requirements: 4.1, 4.2_

  - [ ]* 12.4 Write property test for `parseQuiz` — Property 11
    - **Property 11: Quiz parser returns 2–3 valid question objects**
    - **Validates: Requirements 4.1**
    - Generator for valid input: random JSON arrays of 2–3 well-formed question objects (wrapped in optional markdown fences); assert array length is 2–3 and each object has non-empty `question`, `options`, `correct`, `concept`
    - Generator for invalid input: non-JSON strings, arrays of length 0–1, missing required fields; assert `QuizParseError` is thrown
    - Tag: `// Feature: metacognitive-study-buddy, Property 11`

  - [x] 12.5 Implement `generateQuiz(problem, subject, hints)`
    - Call `fetchWithTimeout(API_URL, requestBody, TIMEOUT_MS)` with the quiz prompt
    - On success: extract `choices[0].message.content`, call `parseQuiz`, return result
    - On network error, timeout, non-2xx response, or `QuizParseError`: throw a typed error with a descriptive message
    - _Requirements: 4.1, 4.7, 7.4_

- [x] 13. Step 4 — Quiz step UI
  - [x] 13.1 Build `#step-quiz` markup
    - `<div id="quiz-container">` (question cards rendered here), `<div id="quiz-result">` (hidden until complete), `<div id="quiz-error">`
    - _Requirements: 4.2, 4.3, 4.4, 4.5_

  - [x] 13.2 Implement `renderQuiz(questions)` and `initQuizStep()`
    - `renderQuiz`: for each question, render a card with escaped question text and option buttons; wire `click` on each option to `handleAnswerSelect(idx, selectedOption)`
    - `initQuizStep`: show `#loading-indicator`, call `generateQuiz`, on success call `renderQuiz`, hide loader; on error call `showError('#quiz-error', message, retryFn)`
    - _Requirements: 4.1, 4.2, 4.3, 4.7_

  - [x] 13.3 Implement `handleAnswerSelect(questionIdx, selectedOption)`
    - Mark the question as `answered = true`; disable all option buttons for that question
    - If `selectedOption === correct`: mark correct feedback (green); set `correct_ = true`; do not show concept
    - If `selectedOption !== correct`: mark incorrect feedback (amber); set `correct_ = false`; display `concept` text beneath the question
    - Check if all questions are answered; if so, call `evaluateQuizResult()` and `incrementCount()`
    - _Requirements: 4.3, 4.4, 4.6_

  - [ ]* 13.4 Write property test for answer selection locking and feedback — Property 12
    - **Property 12: Answer selection locks the question and shows correct feedback**
    - **Validates: Requirements 4.4**
    - Generator: `fc.record({ question: fc.string(), correct: fc.constantFrom('A','B','C','D'), selected: fc.constantFrom('A','B','C','D'), concept: fc.string() })`
    - After calling `handleAnswerSelect`, assert: question is locked; concept shown iff answer is incorrect; no concept shown if correct
    - Tag: `// Feature: metacognitive-study-buddy, Property 12`

  - [x] 13.5 Implement `evaluateQuizResult()`
    - If all `correct_` flags are `true`: display "Ready for similar problems!" in `#quiz-result`
    - Otherwise: display "Review [concept list]" naming all concepts from incorrect answers
    - Use constructive language throughout; do not use "wrong", "failed", or "incorrect attempt"
    - _Requirements: 4.5, 6.4_

  - [ ]* 13.6 Write property test for quiz outcome evaluation — Property 13
    - **Property 13: Final quiz outcome matches the answer pattern**
    - **Validates: Requirements 4.5**
    - Generator: `fc.array(fc.boolean(), { minLength: 2, maxLength: 3 })`
    - Simulate answered quiz with that pattern; if all true assert message is "Ready for similar problems!"; otherwise assert message starts with "Review" and contains relevant concepts
    - Tag: `// Feature: metacognitive-study-buddy, Property 13`

- [x] 14. Checkpoint — Verify QuizEngine and quiz step
  - Ensure all tests pass, ask the user if questions arise.

- [x] 15. App initialisation and API key validation banner
  - [x] 15.1 Build `#step-indicator` markup
    - Four `.step-dot` divs with `data-step` attributes: `input`, `explain`, `hints`, `quiz`
    - Apply active/inactive Tailwind classes via `updateStepIndicator`
    - _Requirements: 1.6, 6.6_

  - [x] 15.2 Build `#progress-tracker` markup
    - `<div id="progress-tracker">Problems practiced: <span id="progress-display">0</span></div>`
    - Position persistently visible above the step indicator
    - _Requirements: 5.2, 5.5_

  - [x] 15.3 Build `#footer` markup
    - `<a id="survey-link" href="...">Take the pre/post survey</a>`
    - OECD attribution sentence: reference the 2026 finding that exam performance dropped despite AI-assisted output improvement
    - _Requirements: 6.7_

  - [x] 15.4 Implement the `init()` IIFE
    - Call `renderCount()` to populate `#progress-display`
    - Call `validateApiKey(API_KEY)`; if false, show `#api-key-error` banner and disable `#start-btn`, `#get-hints-btn`, and `#test-btn`
    - Call `initInputStep()`
    - Call `showStep('step-input')`
    - _Requirements: 7.1_

  - [x] 15.5 Build `#api-key-error` banner markup
    - Hidden by default; shown when `validateApiKey` returns false
    - Descriptive message: "No valid API key found. Set your OpenAI API key in the source file to use this app."
    - _Requirements: 7.1_

- [ ] 16. ErrorHandler module — `showError` and `clearError`
  - [x] 16.1 Implement `showError(containerId, message, retryFn)`
    - Render escaped `message` text and a "Try Again" `<button>` in the target container
    - Attach `retryFn` to the button's `click` event
    - Use constructive error message language (see design error-message tone guidelines)
    - _Requirements: 3.7, 4.7, 6.4_

  - [x] 16.2 Implement `clearError(containerId)`
    - Clear inner HTML of the target container
    - _Requirements: 3.7, 4.7_

- [x] 17. Integration wiring — connect all modules end-to-end
  - [x] 17.1 Verify Input → Explain transition
    - Confirm `currentProblem` and `currentSubject` are stored on `start-btn` click and `showStep('step-explain')` is called
    - _Requirements: 1.4, 1.5_

  - [x] 17.2 Verify Explain → Hints transition
    - Confirm `currentReasoning` is stored on `get-hints-btn` click and `initHintsStep()` is called with correct parameters
    - _Requirements: 2.8, 3.1_

  - [x] 17.3 Verify Hints → Quiz transition
    - Confirm `currentHints` is stored after successful hint generation and `initQuizStep()` is called with correct parameters on `test-btn` click
    - _Requirements: 3.6, 4.1_

  - [x] 17.4 Verify quiz completion increments ProgressTracker
    - Confirm `incrementCount()` is called exactly once after all quiz questions are answered
    - _Requirements: 4.6, 5.4_

- [x] 18. Checkpoint — Full end-to-end verification
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 19. Property-based test suite — remaining properties
  - [ ]* 19.1 Run and verify all 19 PBT assertions pass
    - Confirm each test is tagged with `// Feature: metacognitive-study-buddy, Property N`
    - Confirm each test runs with `{ numRuns: 100 }` (minimum)
    - Properties 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19 must all have corresponding tests in the test suite
    - _Requirements: all_

- [x] 20. Final checkpoint — All acceptance criteria and no console errors
  - Ensure all tests pass, ask the user if questions arise.

---

## Notes

- Tasks marked with `*` are optional and can be skipped for a faster MVP
- Each task references specific requirements for traceability
- All LLM content must pass through `escapeHTML` before DOM insertion (XSS defense)
- The retry function must capture parameters at call time so "Try Again" is idempotent
- `STUCK_QUESTIONS` and `stuckIndex` are module-level; reset `stuckIndex = 0` on each new `initExplainStep()` call
- fast-check is the PBT library; load via `<script src="https://cdn.jsdelivr.net/npm/fast-check/lib/bundle.js"></script>` or from npm in a separate test file
- All user-facing messages must use constructive, outcome-focused language (Requirement 6.4)

---

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["2.1", "2.3", "2.5", "2.6"] },
    { "id": 1, "tasks": ["2.2", "2.4", "2.7", "2.8", "4.1", "5.1"] },
    { "id": 2, "tasks": ["4.2", "4.3", "5.2", "6.1", "16.1", "16.2"] },
    { "id": 3, "tasks": ["6.2", "7.1", "9.1", "9.3", "12.1", "12.3", "15.1", "15.2", "15.3", "15.5"] },
    { "id": 4, "tasks": ["7.2", "7.3", "9.2", "9.4", "12.2", "12.4", "10.1", "13.1"] },
    { "id": 5, "tasks": ["7.4", "7.5", "7.6", "9.5", "10.2", "12.5", "13.2"] },
    { "id": 6, "tasks": ["10.3", "10.4", "13.3", "15.4"] },
    { "id": 7, "tasks": ["13.4", "13.5", "17.1", "17.2", "17.3", "17.4"] },
    { "id": 8, "tasks": ["13.6", "19.1"] }
  ]
}
```
