# Product: Code Dungeon ⚔️

A single-file browser RPG where players defeat dragons by answering AI-generated quiz questions about a coding or math problem they paste in. The game is self-contained — no build step, no server, no accounts.

## Core loop
1. Player pastes a coding/math problem and picks a discipline (Coding or Math)
2. AI (Groq LLaMA 3.3 70B) generates 5 multiple-choice questions based on the problem
3. Correct answers deal damage to the dragon; wrong answers deal damage to the player
4. Defeat all 4 dragon tiers to complete the dungeon
5. Earn XP, level up, and build streak combos across runs

## Key experience goals
- Feels rewarding, not punishing — losing is recoverable
- Immediate visual and audio feedback for every action
- Works on mobile out of the box
- Replayable through user-submitted problems and shuffled question pools

## Audience
Students and developers who want to actively test their understanding of a problem rather than passively read about it.
